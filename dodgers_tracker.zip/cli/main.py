# CLI entry point
