# CLI reporting logic
